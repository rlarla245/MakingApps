package com.example.user.fragment3.NavigationFragments;

/**
 * Created by user on 2018-03-13.
 */

public class NavigationCardViewDTOs {
    public NavigationCardViewDTOs(int imageview, String name, String workspace, String status) {
        this.imageview = imageview;
        this.name = name;
        this.workspace = workspace;
        this.status = status;
    }

    public int imageview;
    public String name, workspace, status;
}
